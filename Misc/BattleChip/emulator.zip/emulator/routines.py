"""
def encrypt_0000(I):
    \"""pre-compiled code
    
    Xor a buffer of size 10 stores at I with a temporary key.
    The secret key is already defined.

    I is copied from the insecure context

    =>  The number of cycles needed to execute this routine
        will be copied at the end of execution in the insecure context.
        The 0xF-th register will contain the value.
    \"""
    [REDACTED]
"""
preco_encrypt = """
6301
62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E

62{:02X}
F065
8023
F055
F31E
FFFF
"""

"""
def verify_0001(I):
    \"""pre-compiled code
    
    Xor a buffer of size 10 stores at I with a temporary key.
    The secret key is already defined.

    I is copied from the insecure context

    =>  0xF-th register in the secure context will be copied
        in the insecure context at the end of this routine execution
    \"""
    [REDACTED]
"""
preco_verify  = """
6101
6200

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

F065
63{:02X}
8303
8231
F11E

8F20
FFFF
"""