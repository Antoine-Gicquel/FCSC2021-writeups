class Keyboard:
    def __getattr__(self, attr):
        raise NotImplementedError(attr)

    def __setattr__(self, attr, value):
        raise NotImplementedError(attr)