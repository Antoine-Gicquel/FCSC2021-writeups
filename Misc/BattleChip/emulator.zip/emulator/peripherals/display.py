import os
import sys

class DisplayError(Exception):
    pass

class OutOfRangeDisplayError(Exception):
    def __init__(self, row, col):
        msg = f"Attempted to set pixel at ({row}, {col})"
        super().__init__(msg)

class Display():
    WEIGHT = 64
    HEIGHT = 32
    FONTS = (
        0xF0, 0x90, 0x90, 0x90, 0xF0,
        0x20, 0x60, 0x20, 0x20, 0x70,
        0xF0, 0x10, 0xF0, 0x80, 0xF0,
        0xF0, 0x10, 0xF0, 0x10, 0xF0,
        0x90, 0x90, 0xF0, 0x10, 0x10,
        0xF0, 0x80, 0xF0, 0x10, 0xF0,
        0xF0, 0x80, 0xF0, 0x90, 0xF0,
        0xF0, 0x10, 0x20, 0x40, 0x40,
        0xF0, 0x90, 0xF0, 0x90, 0xF0,
        0xF0, 0x90, 0xF0, 0x10, 0xF0,
        0xF0, 0x90, 0xF0, 0x90, 0x90,
        0xE0, 0x90, 0xE0, 0x90, 0xE0,
        0xF0, 0x80, 0x80, 0x80, 0xF0,
        0xE0, 0x90, 0x90, 0x90, 0xE0,
        0xF0, 0x80, 0xF0, 0x80, 0xF0,
        0xF0, 0x80, 0xF0, 0x80, 0x80
    )
    PIXEL = u'\u2588'

    def __init__(self, memory=None):
        self.memory = memory
        self.buffer = None
        self.refresh = None
        self.reset()

    def reset(self):
        self.refresh = True
        self.buffer = [
            [False for unused in range(self.WEIGHT)]
            for unused in range(self.HEIGHT)
        ]

    def clear(self):
        self.reset()

    def update(self, i, row, col, n):
        def ntop(i):
            bits = f"{i:08b}"
            return (b == "1" for b in bits)

        cf = 0
        self.refresh = True
        for yline in range(n):
            pixel = self.memory[i + yline]
            for xline, px in enumerate(ntop(pixel)):
                if px == True:
                    try:
                        cf |= self.buffer[row+yline][col+xline] & 1
                    except IndexError:
                        raise OutOfRangeDisplayError(row+yline, col+xline)
                    else:
                        self.buffer[row+yline][col+xline] ^= True
        return cf

    def render(self):
        sys.stdout.write(f"\033[{self.HEIGHT}A\r")
        pixels = ""
        for row in range(self.HEIGHT):
            pixels += "".join(
                [
                    self.PIXEL if self.buffer[row][col] else " " 
                    for col in range(self.WEIGHT)
                ]
            )
            pixels += "\n"
        sys.stdout.write("".join(pixels))
        sys.stdout.flush()

    def cycle(self):
        if self.refresh:
            self.render()
            self.refresh = False