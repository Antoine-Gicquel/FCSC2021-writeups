import abc

class Timer(abc.ABC):
    def __init__(self):
        self._timer = None
        self.reset()

    def reset(self):
        self._timer = bytearray(1)

    @abc.abstractmethod
    def callback(self):
        return

    @property
    def timer(self):
        return self._timer[0]

    @timer.setter
    def timer(self, v):
        self._timer[0] = v
    
    def cycle(self):
        if self.timer > 0:
            self.timer = self.timer - 1
            if self.timer == 0:
                self.callback()

class Clock(Timer):
    def callback(self):
        return

class Buzzer(Timer):
    def callback(self):
        sys.stdout.write("\a")
        sys.stdout.flush()