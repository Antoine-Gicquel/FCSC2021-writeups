import functools
import enum

def request(func):
    wanted = None
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        nonlocal wanted
        if wanted is not None:
            ret = ALU.Status.AVAILABLE, wanted
            wanted = None
            return ret
        misses = func.cache_info().misses
        ret = func(*args, **kwargs)
        if func.cache_info().misses == misses:
            return ALU.Status.AVAILABLE, ret
        wanted = ret
        return ALU.Status.PENDING, (None, None)
    return wrapper

class Singleton(type):
    instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls.instances:
            cls.instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls.instances[cls]

class ALU(metaclass=Singleton):
    class Status(enum.IntEnum):
        PENDING = 0
        AVAILABLE = 1

    cached_methods = ["or_", "and_", "xor", "add", "sub", "sal", "sar"]

    @request
    @functools.lru_cache(maxsize=16)
    def or_(self, a, b):
        return a | b, 0

    @request
    @functools.lru_cache(maxsize=16)
    def and_(self, a, b):
        return a & b, 0

    @request
    @functools.lru_cache(maxsize=16)
    def xor(self, a, b):
        return a ^ b, 0

    @request
    @functools.lru_cache(maxsize=16)
    def add(self, a, b):
        return (a + b) & 0xFF, (b > (0xFF - a)) & 1

    @request
    @functools.lru_cache(maxsize=16)
    def sub(self, a, b):
        return (a - b) & 0xFF, (b <= a) & 1

    @request
    @functools.lru_cache(maxsize=16)
    def sal(self, a):
        return (a << 1) & 0xFF, (a & 0x80) >> 7

    @request
    @functools.lru_cache(maxsize=16)
    def sar(self, a):
        return a >> 1, a & 1

    def reset(self):
        for func_name in self.cached_methods:
            getattr(self, func_name).__wrapped__.cache_clear()