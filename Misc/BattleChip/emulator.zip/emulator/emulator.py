from components.processor import Processor
from components.memory import Memory
from components.cu import ControlUnit
from components.alu import ALU
from peripherals.display import Display
from peripherals.timer import (Clock, Buzzer)
#from peripherals.keyboard import Keyboard

import routines
import flag

import io
import os

class CPU:
    def __init__(self):
        self.clock = None
        self.buzzer = None

        self.processor = Processor()
        self.control_unit = ControlUnit()
        self.context = None
        self.alu = ALU()
        self.tick = 0

        self.control_unit.cpu = self

    def cycle(self):
        self.control_unit.cycle()
        self.tick = (self.tick + 1) & 0xFF

    def reset(self):
        self.processor.reset()
        self.control_unit.reset()
        # self.alu.reset()
        self.tick = 0


class IO:
    def __init__(self):
        self.display = Display()

    def reset(self):
        self.display.reset()

    def cycle(self):
        self.display.cycle()


class BaseContext:
    def __init__(self):
        self.memory = Memory()
        self.cpu = CPU()
        self.clock = Clock()
        self.buzzer = Buzzer()

        self.cpu.control_unit.memory = self.memory
        self.cpu.clock = self.clock
        self.cpu.buzzer = self.buzzer

    def reset(self):
        self.memory.reset()
        self.cpu.reset()
        self.clock.reset()
        self.buzzer.reset()

    def cycle(self):
        self.cpu.cycle()
        self.clock.cycle()
        self.buzzer.cycle()

    def run(self):
        while 1:
            try:
                self.cycle()
            except SystemExit as e:
                break

    def load(self, hex_rom):
        rom = bytes.fromhex(hex_rom)
        self.memory.load_rom(
            io.BytesIO(
                rom
            )
        )
        self.cpu.control_unit.pc = self.memory.O_ROM
        self.cpu.control_unit.sp = self.memory.O_STACK

class UntrustedContext(BaseContext):
    def __init__(self):
        super().__init__()
        self.secure_element = None

        self.io = IO()

        self.io.display.memory = self.memory
        self.cpu.context = self

    def reset(self):
        super().__init__()
        self.io.reset()

    def cycle(self):
        super().cycle()
        self.io.cycle()


class TrustedContext(BaseContext):
    def __init__(self):
        super().__init__()
        self.execution_key = os.urandom(10)
        self.co_encrypt = routines.preco_encrypt.format(*self.execution_key)
        self.co_verify = routines.preco_verify.format(*self.execution_key)

    def set_context(self, i=None, memory=None):
        if i:
            self.cpu.processor.i = i
        if memory:
            assert len(memory) == Memory.SIZE - Memory.O_STACK
            self.memory.data[Memory.O_STACK:Memory.SIZE] = memory

    def exc_encrypt(self):
        self.load(self.co_encrypt)
        self.run()

    def exc_verify(self):
        self.load(self.co_verify)
        self.run()
        return flag.FLAG_LV2


class Emulator:
    def __init__(self):
        self.untrusted_ctx = UntrustedContext()
        self.trusted_context = TrustedContext()

        self.untrusted_ctx.secure_element = self.trusted_context
        
    def reset(self):
        self.untrusted_ctx.reset()
        self.trusted_context.reset()

    def load(self, hex_rom):
        self.untrusted_ctx.load(hex_rom)

    def run(self):
        self.untrusted_ctx.run()
