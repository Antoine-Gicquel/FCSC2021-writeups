import emulator
import sys

def main():
    vm = emulator.Emulator()
    sys.stdout.write("hex encoded rom:\n")
    sys.stdout.flush()
    data = sys.stdin.readlines(1)[0]
    vm.load(data)
    vm.run()
    
if __name__ == "__main__":
    main()